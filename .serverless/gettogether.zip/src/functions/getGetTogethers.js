const AWS = require("aws-sdk");
const chance = require("chance").Chance();
const sns = new AWS.SNS();

module.exports.handler = async (event, context) => {
  const body = JSON.parse(event.body);
  const orderId = body.orderId;
  const getTogetherId = body.getTogetherId;
  const userEmail = body.userEmail;
  
  const notificationData = {
    orderId,
    getTogetherId,
    userEmail
  }

  const notification = {
      'Message' : JSON.stringify(notificationData),
      'TopicArn' : 'dev-joingettogethers'
  } 

  await sns.publish(notification).promise();
  
  console.log(notification);

  const response = {
    statusCode: 200,
    body: JSON.stringify({ userEmail })
  };

  return response;
};